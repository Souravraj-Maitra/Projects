CREATE DATABASE employee;

SELECT * FROM proj_table;
SELECT * FROM emp_record_table ORDER BY manager_id;
SELECT * FROM data_science_team;

-- First change the column name from 'start _date' to 'start_date'
ALTER TABLE proj_table RENAME COLUMN `start _date` TO `start_date`;

SELECT project_id,proj_name,domain,start_date,closure_date,dev_qtr,status FROM proj_table;

SELECT start_date FROM proj_table;

SELECT REPLACE(start_date,'-','/') FROM proj_table;

SELECT closure_date FROM proj_table;

SELECT STR_TO_DATE(REPLACE(closure_date,'-','/'),'%m/%d/%Y') FROM proj_table;

SELECT STR_TO_DATE(REPLACE(start_date,'-','/'),'%m/%d/%Y') FROM proj_table;

-- Displaying the correct format before permanent change to the proj_table
SELECT project_id,proj_name,domain,DATE_FORMAT(STR_TO_DATE(REPLACE(start_date,'-','/'),'%m/%d/%Y'),"%d/%m/%Y") AS start_date,DATE_FORMAT(STR_TO_DATE(REPLACE(closure_date,'-','/'),'%m/%d/%Y'),"%d/%m/%Y") AS closure_date,dev_qtr,status FROM proj_table;

SELECT project_id,proj_name,domain,STR_TO_DATE(REPLACE(start_date,'-','/'),'%m/%d/%Y') AS start_date,STR_TO_DATE(REPLACE(closure_date,'-','/'),'%m/%d/%Y') AS closure_date,dev_qtr,status FROM proj_table;

-- Setting proj_id to NULL for those whose value is NA
UPDATE emp_record_table
SET proj_id=null
WHERE proj_id='NA';

-- Modifying proj_table
CREATE TABLE proj_table_1 AS SELECT project_id,proj_name,domain,STR_TO_DATE(REPLACE(start_date,'-','/'),'%m/%d/%Y') AS start_date,STR_TO_DATE(REPLACE(closure_date,'-','/'),'%m/%d/%Y') AS closure_date,dev_qtr,status FROM proj_table;
DROP TABLE proj_table;
ALTER TABLE proj_table_1 RENAME proj_table;

-- Adding the constraints
ALTER TABLE emp_record_table MODIFY COLUMN emp_id VARCHAR(255);
ALTER TABLE emp_record_table MODIFY COLUMN proj_id VARCHAR(255);
ALTER TABLE data_science_team MODIFY COLUMN emp_id VARCHAR(255);
ALTER TABLE proj_table MODIFY COLUMN project_id VARCHAR(255);


ALTER TABLE emp_record_table ADD CONSTRAINT PRIMARY KEY(emp_id);
ALTER TABLE data_science_team ADD CONSTRAINT PRIMARY KEY(emp_id);
ALTER TABLE proj_table ADD CONSTRAINT PRIMARY KEY(project_id);

ALTER TABLE emp_record_table ADD CONSTRAINT FOREIGN KEY(proj_id) REFERENCES proj_table(project_id); 
ALTER TABLE data_science_team ADD CONSTRAINT FOREIGN KEY(emp_id) REFERENCES emp_record_table(emp_id); 

-- Describe the tables
DESC data_science_team;
DESC emp_record_table;
DESC proj_table;

ALTER TABLE emp_record_table ADD CONSTRAINT PRIMARY KEY(EMP_ID);

/*--------------------------------------------------------------------------------------------------------*/

-- Assignment
-- Table 1:data_science_team
-- Table 2:emp_record_table
-- Table 3:proj_table

-- 3. Write a query to fetch EMP_ID, FIRST_NAME, LAST_NAME, GENDER, and
-- DEPARTMENT from the employee record table, and make a list of employees
-- and details of their department.

SELECT emp_id, first_name, last_name, gender, dept FROM emp_record_table;

-- 4. Write a query to fetch EMP_ID, FIRST_NAME, LAST_NAME, GENDER,
-- DEPARTMENT, and EMP_RATING if the EMP_RATING is:
-- ● less than two
-- ● greater than four
-- ● between two and four

SELECT emp_id,first_name,last_name,gender,dept,emp_rating 
FROM emp_record_table
WHERE emp_rating < 2;

SELECT emp_id,first_name,last_name,gender,dept,emp_rating 
FROM emp_record_table
WHERE emp_rating > 4;

SELECT emp_id,first_name,last_name,gender,dept,emp_rating 
FROM emp_record_table
WHERE emp_rating BETWEEN 2 AND 4;


-- 5. Write a query to concatenate the FIRST_NAME and the LAST_NAME of
-- employees in the Finance department from the employee table and then give
-- the resultant column alias as NAME.

SELECT TRIM(CONCAT(first_name," ",last_name)) AS Name 
FROM emp_record_table
WHERE dept='Finance';


-- 6. Write a query to list only those employees who have someone reporting to
-- them. Also, show the number of reporters (including the President).

SELECT CONCAT(manager.first_name," ",manager.last_name) AS Manager_Name,COUNT(*) AS No_of_reporters
FROM emp_record_table employee INNER JOIN emp_record_table manager
	ON manager.emp_id=employee.manager_id
GROUP BY CONCAT(manager.first_name," ",manager.last_name)
ORDER BY CONCAT(manager.first_name," ",manager.last_name);


-- 7. Write a query to list down all the employees from the healthcare and finance
-- departments using union. Take data from the employee record table.

SELECT CONCAT(first_name," ",last_name) AS Employees,dept FROM(
	SELECT * FROM emp_record_table WHERE DEPT='healthcare'
	UNION
	SELECT * FROM emp_record_table WHERE DEPT='finance'
)AS Merged_Table
ORDER BY dept;



-- 8. Write a query to list down employee details such as EMP_ID, FIRST_NAME,
-- LAST_NAME, ROLE, DEPARTMENT, and EMP_RATING grouped by dept. Also
-- include the respective employee rating along with the max emp rating for the
-- department.

SELECT emp_id, first_name, last_name, role, dept, emp_rating,MAX(emp_rating) OVER(PARTITION BY dept ORDER BY emp_rating DESC)
FROM emp_record_table;


-- 9. Write a query to calculate the minimum and the maximum salary of the
-- employees in each role. Take data from the employee record table.

SELECT role,MIN(salary) AS min_salary,MAX(salary) AS max_salary
FROM emp_record_table
GROUP BY role;


-- 10. Write a query to assign ranks to each employee based on their experience.
-- Take data from the employee record table.

SELECT CONCAT(first_name," ",last_name) AS Employees,exp AS Experience ,DENSE_RANK() OVER(ORDER BY exp DESC) AS Rank_based_on_experience
FROM emp_record_table;


-- 11. Write a query to create a view that displays employees in various countries
-- whose salary is more than six thousand. Take data from the employee record
-- table.

CREATE VIEW Emp_records_view_1 AS
SELECT CONCAT(first_name," ",last_name) AS Employees, country, salary FROM emp_record_table WHERE salary>6000 ORDER BY salary;

SELECT * FROM Emp_records_view_1;

DROP VIEW Emp_records_view_1;

-- 12. Write a nested query to find employees with experience of more than ten
-- years. Take data from the employee record table.

SELECT CONCAT(first_name," ",last_name) AS Employees,exp AS Experience FROM (SELECT * FROM emp_record_table WHERE exp>10 ORDER BY exp) AS Emp_exp_more_than_10;


-- 13. Write a query to create a stored procedure to retrieve the details of the
-- employees whose experience is more than three years. Take data from the
-- employee record table.

DELIMITER //
CREATE PROCEDURE Emp_exp_more_than_3()
BEGIN
	SELECT * FROM emp_record_table WHERE exp>3;
END //

CALL Emp_exp_more_than_3;

DROP PROCEDURE Emp_exp_more_than_3;


-- 14. Write a query using stored functions in the project table to check whether
-- the job profile assigned to each employee in the data science team matches
-- the organization’s set standard.
-- The standard being:
-- For an employee with experience less than or equal to 2 years assign 'JUNIOR
-- DATA SCIENTIST',
-- For an employee with the experience of 2 to 5 years assign 'ASSOCIATE DATA
-- SCIENTIST',
-- For an employee with the experience of 5 to 10 years assign 'SENIOR DATA
-- SCIENTIST',
-- For an employee with the experience of 10 to 12 years assign 'LEAD DATA
-- SCIENTIST',
-- For an employee with the experience of 12 to 16 years assign 'MANAGER'.

DELIMITER //
CREATE FUNCTION Job_Profile(exp INT)
RETURNS text
DETERMINISTIC
BEGIN
	RETURN (CASE
		WHEN exp<=2 THEN "junior data scientist"
		WHEN exp<=5 THEN "associate data scientist"
		WHEN exp<=10 THEN "senior data scientist"
		WHEN exp<=12 THEN "lead data scientist"
		WHEN exp<=16 THEN "manager"
        ELSE "NA"
        END);
END //


SELECT role,IF(role=Job_Profile(exp),"Yes",IF(Job_Profile(exp)="NA","Not sure","No")) AS "Meets the organization standard?" 
FROM data_science_team
GROUP BY role,Job_Profile(exp),IF(role=Job_Profile(exp),"Yes",IF(Job_Profile(exp)="NA","Not sure","No"));

DROP FUNCTION Job_Profile;
SELECT * FROM data_science_team;



-- 16. Write a query to calculate the bonus for all the employees, based on their
-- ratings and salaries (Use the formula: 5% of salary * employee rating).

SELECT CONCAT(first_name," ",last_name) AS Employees,0.05*salary*emp_rating AS "Bonus" 
FROM emp_record_table; 

DESC emp_record_table;


-- 17. Write a query to calculate the average salary distribution based on the
-- continent and country. Take data from the employee record table.

SELECT continent,country,AVG(salary) AS Avg_Salary
FROM emp_record_table
GROUP BY continent,country
ORDER BY continent,country;


-- ---------------------------------------------------------------------------------------------------------

ALTER TABLE emp_record_table MODIFY first_name VARCHAR(100);

-- 15. Create an index to improve the cost and performance of the query to find
-- the employee whose FIRST_NAME is ‘Eric’ in the employee table after
-- checking the execution plan.

SELECT CONCAT(first_name," ",last_name) AS Employees 
FROM emp_record_table
WHERE first_name="Eric";

EXPLAIN SELECT *
FROM emp_record_table
WHERE first_name="Eric";

CREATE INDEX Emp_Index ON emp_record_table(first_name);

DROP INDEX Emp_Index ON emp_record_table;
SHOW INDEXES FROM emp_record_table;

DESC emp_record_table;
